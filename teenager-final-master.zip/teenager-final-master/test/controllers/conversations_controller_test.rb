require 'test_helper'

class ConversationsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
