require 'test_helper'

class BlogPostsHelperTest < ActionView::TestCase
end
