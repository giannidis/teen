require 'test_helper'

class MailboxHelperTest < ActionView::TestCase
end
